export const environment = {
  production: true,
  apiUrl: 'https://api.jikan.moe/v4/'
};
