import { Component, OnInit } from '@angular/core';

@Component({
  standalone: false,
  selector: 'app-anime-detail',
  templateUrl: './anime-detail.component.html',
  styleUrls: ['./anime-detail.component.scss'],
})
export class AnimeDetailComponent  implements OnInit {

  constructor() { }

  ngOnInit() {}

}
