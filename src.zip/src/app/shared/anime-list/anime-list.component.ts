import { Component, OnInit } from '@angular/core';

@Component({
  standalone: false,
  selector: 'app-anime-list',
  templateUrl: './anime-list.component.html',
  styleUrls: ['./anime-list.component.scss'],
})
export class AnimeListComponent  implements OnInit {

  constructor() { }

  ngOnInit() {}

}
